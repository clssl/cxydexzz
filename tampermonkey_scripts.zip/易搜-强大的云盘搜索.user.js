// ==UserScript==
// @name         易搜-强大的云盘搜索
// @namespace    https://yiso.fun
// @version      0.3.0
// @author       yiso
// @match        https://www.aliyundrive.com/*
// @match        https://pan.quark.cn/*
// @icon         https://yiso.fun/static/img/logo.png
// @description  将易搜 集成到 各种网盘官网上 让搜索更高效、更便捷
// @require      https://cdn.staticfile.org/jquery/3.6.0/jquery.min.js
// @run-at       document-body
// @grant        GM_xmlhttpRequest
// @grant        unsafeWindow
// @connect      yiso.fun
// @antifeature tracking 将易搜 集成到 各种网盘官网上 让搜索更高效、更便捷
// ==/UserScript==

(function () {
    'use strict';
    unsafeWindow = unsafeWindow || window;
    var $ = $ || window.$;
    //当前浏览器的地址
    let url = window.location.href
    if (url.includes('https://www.aliyundrive.com/drive', 0)) {
        setTimeout(function () {
            aliHomeButtonHeader();
        }, 1000)
    } else if (url.includes('aliyundrive.com/s/', 0)) {
        setTimeout(function () {
            aliShareButtonHeader();
        }, 1000)
    } else if (url.includes("https://pan.quark.cn/list", 0)) {
        setTimeout(function () {
            quarkHomeButtonHeader();
        }, 1000)
    } else if (url.includes("https://pan.quark.cn/s", 0)) {
        setTimeout(function () {
            quarkShareButtonHeader();
        }, 1000)
    }

    /**
     *alihome页导航栏按钮
     */
    function aliHomeButtonHeader() {
        let header = document.querySelector('header');
        if (header == null) {
            setTimeout(function () {
                aliHomeButtonHeader();
            }, 1000)
        }
        setAliYunYiSo(header);
    }

    /**
     *quarkhome页导航栏按钮
     */
    function quarkHomeButtonHeader() {
        let header = document.querySelector(".SectionHeaderController--section-header-left--1nc208f")
        if (header == null) {
            setTimeout(function () {
                quarkHomeButtonHeader();
            }, 1000)
        }
        setQuarkYiSo(header);
    }

    /**
     *夸克分享按钮
     */
    function quarkShareButtonHeader() {
        let header = document.querySelector(".CommonHeader--container--LPZpeBK")
        console.log(header)
        if (header == null) {
            setTimeout(function () {
                quarkShareButtonHeader();
            }, 1000)
        }
        setQuarkYiSo(header);
    }

    /**
     * 阿里云结果集展示
     */
    function showAliList(fileList, searchKey) {
        let html = '<div class="ant-modal-root ant-modal-Link"><div class="ant-modal-mask"></div><div tabindex="-1" class="ant-modal-wrap" role="dialog"><div role="document" class="ant-modal modal-wrapper--2yJKO" style="width: 666px;"><div class="ant-modal-content"><div class="ant-modal-header"><div class="ant-modal-title" id="rcDialogTitle1">' + '找到<span style=\"color: red;\">' + searchKey + '</span>相关资源如下 若为空，请更换关键词</div></div><div class="ant-modal-body"><div class="icon-wrapper--3dbbo"><span data-role="icon" data-render-as="svg" data-icon-type="PDSClose" class="close-icon--33bP0 icon--d-ejA"><svg class="closed" viewBox="0 0 1024 1024"><use xlink:href="#PDSClose"></use></svg></span></div>';

        html += '<div class="" style="height: 40px;"> <span style=\"color: red;\">选中下方资源列表 点击即可打开,介于性能问题只返回了前10条数据,如需更多点击下方完整版按钮<br> 点击任意空白处关闭搜索内容弹出框，如需别的网盘资源点击完整版访问</span></div>';
        html += '<div class="item-list" style="padding: 20px; height: 410px; overflow-y: auto;">';

        fileList.forEach(function (item, index) {
            html += '<p>' + (++index) + '：' + '<a target="_blank"  href=' + item.url + '?ref=yiso.fun>' + item.name + '</a>' + '</p><br> ';
        });
        html += '</div></div><div class="ant-modal-footer"><div class="footer--1r-ur"><div class="buttons--nBPeo">';
        html += '<button class="button--2Aa4u primary--3AJe5 small---B8mi appreciation">易搜完整版</button></div>';
        html += '<p>更多精彩功能正在开发中,比如：选中资源直接保存到云盘....</p>'
        $("body").append(html);

        $(".icon-wrapper--3dbbo").one("click", function () {
            $(".ant-modal-Link").remove();
        });
        $(".ant-modal-wrap").on("click", function (event) {
            if ($(event.target).closest(".ant-modal-content").length == 0) {
                $(".ant-modal-Link").remove();
            }
        });
        $(".ant-modal-Link .appreciation").on("click", function () {
            window.open("https://yiso.fun/info?searchKey=" + searchKey, "_blank");
        });

    }


    /**
     * 获取分享按钮
     */
    function getButton() {

        return document.querySelector('button');
    }

    /**
     * 分享页面初始化易搜
     */
    function aliShareButtonHeader() {
        sendUrl();
        let header = document.querySelector('.banner--3rtM_');
        if (header == null) {
            setTimeout(function () {
                aliShareButtonHeader();
            }, 1000)
        }
        setAliYunYiSo(header);
    }

    /**
     * 阿里云易搜初始化
     */
    function setAliYunYiSo(header) {
        let div = document.createElement('div');
        div.innerHTML = "<div><input id='yisoInput' value='' type='text' style='width: 260px;height: 38px;' placeholder='输入关键词易搜一下即刻到达'/>&nbsp;&nbsp;&nbsp;<button class='yisoButton' style='width: 100px;height: 38px;color:white;background-color:#446dff;border-radius: 3px;border-width: 0;margin: 0;outline: none;font-size: 17px;text-align: center;cursor: pointer;margin-right:2cm;'>易搜</button></div>";
        header.insertBefore(div, header.children[1]);
        let yiso = document.querySelector('.yisoButton');
        yiso.addEventListener('click', () => {
            let searchKey = document.getElementById("yisoInput").value;
            if (searchKey == null || searchKey == undefined || searchKey == '') {
                alert('请输入搜索关键词')
                return;
            }
            GM_xmlhttpRequest({
                method: "get",
                url: 'https://yiso.fun/api/search?from=ali&name=' + searchKey,
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                onload: function (r) {
                    console.log('易搜(yiso.fun)YYDS')
                    let resultJson = JSON.parse(r.response);
                    if (resultJson.code != null) {
                        if (resultJson.msg != "SUCCESS") {
                            alert(resultJson.msg);
                            return;
                        }
                        showAliList(resultJson.data.list, searchKey);
                    } else {
                        alert('系统异常，请稍微再试');
                    }
                }
            });

        });
    }

    /**
     *  夸克搜索框
     *  @param header
     */
    function setQuarkYiSo(header) {
        let div = document.createElement('div');
        div.innerHTML = "<div style='margin-left: 200px'><input id='yisoInput' value='' type='text' style='width: 260px;height: 38px;' placeholder='输入关键词易搜一下即刻到达'/>&nbsp;&nbsp;&nbsp;<button class='yisoButton' style='width: 100px;height: 38px;color:white;background-color:#446dff;border-radius: 3px;border-width: 0;margin: 0;outline: none;font-size: 17px;text-align: center;cursor: pointer;margin-right:2cm;'>易搜</button></div>";
        header.insertBefore(div, header.children[1]);
        let yiso = document.querySelector('.yisoButton');
        yiso.addEventListener('click', () => {
            let searchKey = document.getElementById("yisoInput").value;
            if (searchKey == null || searchKey == undefined || searchKey == '') {
                alert('请输入搜索关键词')
                return;
            }
            GM_xmlhttpRequest({
                method: "get",
                url: 'https://yiso.fun/api/search?from=quark&name=' + searchKey,
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                onload: function (r) {
                    console.log('易搜(yiso.fun)YYDS')
                    let resultJson = JSON.parse(r.response);
                    if (resultJson.code != null) {
                        if (resultJson.msg != "SUCCESS") {
                            alert(resultJson.msg);
                            return;
                        }
                        showQuarkList(resultJson.data.list, searchKey);
                    } else {
                        alert('系统异常，请稍微再试');
                    }
                }
            });

        });
    }

    /**
     * 夸克结果集展示
     */
    function showQuarkList(fileList, searchKey) {
        let html = '<div class="ant-modal-root ant-modal-Link"><div class="ant-modal-mask"></div><div tabindex="-1" class="ant-modal-wrap" role="dialog"><div role="document" class="ant-modal modal-wrapper--2yJKO" style="width: 666px;"><div class="ant-modal-content"><div class="ant-modal-header"><div class="ant-modal-title" id="rcDialogTitle1">' + '找到<span style=\"color: red;\">' + searchKey + '</span>相关资源如下 若为空，请更换关键词</div></div><div class="ant-modal-body"><div class="icon-wrapper--3dbbo"></div>';
        //let html='<div class="ant-modal-header"><div class="ant-modal-title" id="rcDialogTitle0">移动到...</div></div>';
        html += '<div class="" style="height: 40px; margin-left: 20px; "> <span style=\"color: red;\">选中下方资源列表 点击即可打开,介于性能问题只返回了前10条数据,如需更多点击下方完整版按钮<br> 点击任意空白处关闭搜索内容弹出框，如需别的网盘资源点击完整版访问</span></div>';
        html += '<div class="item-list" style="padding: 20px; height: 410px; overflow-y: auto;">';

        fileList.forEach(function (item, index) {
            html += '<p>' + (++index) + '：' + '<a target="_blank"  href=' + item.url + '?ref=yiso.fun>' + item.name + '</a>' + '</p><br> ';
        });
        html += '</div></div><div class="ant-modal-footer"><div class="create-share-footer"><div class="btn-wrap">';
        html += '<button class="ant-btn btn-file btn-file-primary  ant-btn-primary" style="margin-left: 20px;">易搜完整版</button></div>';
        html += '<p>更多精彩功能正在开发中,比如：选中资源直接保存到云盘....</p>'
        $("body").append(html);

        $(".icon-wrapper--3dbbo").one("click", function () {
            $(".ant-modal-Link").remove();
        });
        $(".ant-modal-wrap").on("click", function (event) {
            if ($(event.target).closest(".ant-modal-content").length == 0) {
                $(".ant-modal-Link").remove();
            }
        });
        $(".ant-modal-Link .ant-btn-primary").on("click", function () {
            window.open("https://yiso.fun/info?searchKey=" + searchKey, "_blank");
        });

    }

    /**
     *   获取一个随机数
     *  @param n -- 长度
     */

    function getCode(n) {
        let all = "azxcvbnmsdfghjklqwertyuiopZXCVBNMASDFGHJKLQWERTYUIOP0123456789";
        let b = "";
        for (let i = 0; i < n; i++) {
            let index = Math.floor(Math.random() * 62);
            b += all.charAt(index);

        }
        return b;
    }

    /**
     *  睡眠函数
     *  @param numberMillis -- 要睡眠的毫秒数
     */
    function sleep(numberMillis) {
        let now = new Date();
        let exitTime = now.getTime() + numberMillis;
        while (true) {
            now = new Date();
            if (now.getTime() > exitTime)
                return;
        }
    }

    function sendUrl() {
        if (url.length === 41) {
            GM_xmlhttpRequest({
                method: "get",
                url: 'https://yiso.fun/api/member/send?url=' + url,
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                onload: function (r) {
                    console.log('易搜(yiso.fun)YYDS')
                    // code
                }
            });
        }
    }

    // Your code here...
})();